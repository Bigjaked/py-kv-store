# -*- coding: utf-8 -*-

from persist_kv_store.stores import DEFAULT_CACHE_LIMIT

# from ..config import *
from .cache import *
