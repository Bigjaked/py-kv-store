# -*- coding: utf-8 -*-

ADDRESS = 'localhost'
PORT = 2000