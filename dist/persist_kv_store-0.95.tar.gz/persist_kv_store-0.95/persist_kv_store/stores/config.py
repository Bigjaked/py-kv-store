# -*- coding: utf-8 -*-

DEFAULT_CACHE_LIMIT = 1000
